package pack;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Supplier supplier1 = new Supplier(1, "Monika");
        Supplier supplier2 = new Supplier(2, "Ram");

        List<Product> productList = Arrays.asList(
                new Product(201, "Almonds", "dry fruits", 1.0, 500.0, LocalDate.now().plusDays(30), supplier1),
                new Product(202, "Brown Rice", "grains", 5.0, 300.0, LocalDate.now().plusDays(60), supplier2),
                new Product(203, "Olive Oil", "oils", 2.0, 700.0, LocalDate.now().plusDays(45), supplier1),
                new Product(204, "Honey", "sweeteners", 0.5, 250.0, LocalDate.now().plusDays(90), supplier2),
                new Product(205, "Cashews", "dry fruits", 1.5, 650.0, LocalDate.now().minusDays(2), supplier1),
                new Product(206, "Green Tea", "beverages", 1.0, 200.0, LocalDate.now().minusDays(5), supplier2)
        );

        ProductService productService = new ProductService(productList);

        Optional<Product> highestPricedProduct = productService.getHighestPricedProduct();
        highestPricedProduct.ifPresent(product -> System.out.println("Most Expensive Product: " + product));

        Optional<Product> lowestPricedProduct = productService.getLowestPricedProduct();
        lowestPricedProduct.ifPresent(product -> System.out.println("Least Expensive Product: " + product));

        List<Product> expiredProducts = productService.getExpiredProducts();
        System.out.println("Products Expired: " + expiredProducts);

        List<String> productsExpiringInNext10Days = productService.getProductsExpiringInNext10Days();
        System.out.println("Upcoming Expirations (Next 10 Days): " + productsExpiringInNext10Days);

        System.out.println("Number of Products in Each Category: " + productService.getProductTypeCount());
        System.out.println("Number of Products Provided by Each Supplier: " + productService.getSupplierProductCount());
    }
}

