package pack;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class ProductService {
    private List<Product> products;

    public ProductService(List<Product> products) {
        this.products = products;
    }

    public Optional<Product> getHighestPricedProduct() {
        return products.stream().max(Comparator.comparing(Product::getPrice));
    }

    public Optional<Product> getLowestPricedProduct() {
        return products.stream().min(Comparator.comparing(Product::getPrice));
    }

    public List<Product> getExpiredProducts() {
        return products.stream()
                .filter(product -> product.getExpiryDate().isBefore(LocalDate.now()))
                .collect(Collectors.toList());
    }

    public List<String> getProductsExpiringInNext10Days() {
        LocalDate today = LocalDate.now();
        LocalDate tenDaysLater = today.plusDays(10);
        return products.stream()
                .filter(product -> !product.getExpiryDate().isBefore(today) && product.getExpiryDate().isBefore(tenDaysLater))
                .map(Product::getName)
                .collect(Collectors.toList());
    }

    public Map<String, Long> getProductTypeCount() {
        return products.stream()
                .collect(Collectors.groupingBy(Product::getType, Collectors.counting()));
    }

    public Map<String, Long> getSupplierProductCount() {
        return products.stream()
                .collect(Collectors.groupingBy(product -> product.getSupplier().getSname(), Collectors.counting()));
    }
}
