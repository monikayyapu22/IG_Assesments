package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import exception.ScholarNotFoundException;
import model.Scholar;
import util.DBUtil;

public class ScholarDaoImpl implements ScholarDao {
    public void addScholar(Scholar scholar) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement pst = con.prepareStatement("INSERT INTO Scholar VALUES (?, ?, ?, ?)");
        pst.setInt(1, scholar.getScholarId());
        pst.setString(2, scholar.getName());
        pst.setString(3, scholar.getEmail());
        pst.setString(4, scholar.getMobile());
        pst.executeUpdate();
    }
    public Scholar getOneScholar(Integer scholarId) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement pst = con.prepareStatement("SELECT * FROM Scholar WHERE Rollno = ?");
        pst.setInt(1, scholarId);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            return new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile"));
        } else {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
    }
    public List<Scholar> listAllScholars() throws Exception {
        Connection con = DBUtil.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM Scholar");

        List<Scholar> scholars = new ArrayList<>();
        while (rs.next()) {
            scholars.add(new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile")));
        }
        return scholars;
    }
    public void updateScholarEmail(Integer scholarId, String newEmail) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement pst = con.prepareStatement("UPDATE Scholar SET Email = ? WHERE Rollno = ?");
        pst.setString(1, newEmail);
        pst.setInt(2, scholarId);
        int rowsUpdated = pst.executeUpdate();

        if (rowsUpdated == 0) {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
    }
    public void deleteScholarById(Integer scholarId) throws Exception {
        Connection con = DBUtil.getConnection();
        PreparedStatement pst = con.prepareStatement("DELETE FROM Scholar WHERE Rollno = ?");
        pst.setInt(1, scholarId);
        int rowsDeleted = pst.executeUpdate();

        if (rowsDeleted == 0) {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
    }
}
