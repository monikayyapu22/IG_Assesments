package dao;

import java.util.List;
import model.Scholar;

public interface ScholarDao {
    void addScholar(Scholar scholar) throws Exception;
    
    Scholar getOneScholar(Integer scholarId) throws Exception;
    List<Scholar> listAllScholars() throws Exception;
    void updateScholarEmail(Integer scholarId, String newEmail) throws Exception;
    void deleteScholarById(Integer scholarId) throws Exception;
}
