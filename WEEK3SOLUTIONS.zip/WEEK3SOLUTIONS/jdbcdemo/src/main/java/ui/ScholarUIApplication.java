package ui;

import java.util.List;
import java.util.Scanner;
import model.Scholar;
import service.ScholarService;
import service.ScholarServiceImpl;
import exception.ScholarNotFoundException;

public class ScholarUIApplication {
    public static void main(String[] args) {
        ScholarService service = new ScholarServiceImpl();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. insert/add a new Scholar");
            System.out.println("2. Get details of Scholar by their ID");
            System.out.println("3. Display All Scholars");
            System.out.println("4. Update Email of sCHolar");
            System.out.println("5. Delete Scholar");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            try {
                if (choice == 1) {
                    System.out.print("Enter Scholar ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    System.out.print("Enter Mobile: ");
                    String mobile = sc.nextLine();
                    service.addScholar(new Scholar(id, name, email, mobile));
                    System.out.println("inserted successfully!");
                } else if (choice == 2) {
                    System.out.print("Enter Scholar ID: ");
                    System.out.println(service.getOneScholar(sc.nextInt()));
                } else if (choice == 3) {
                    List<Scholar> scholars = service.listAllScholars();
                    scholars.forEach(System.out::println);
                } else if (choice == 4) {
                    System.out.print("Enter Scholar ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Email: ");
                    String email = sc.nextLine();
                    service.updateScholarEmail(id, email);
                    System.out.println("updated Email successfully!");
                } else if (choice == 5) {
                    System.out.print("Enter Scholar ID: ");
                    service.deleteScholarById(sc.nextInt());
                    System.out.println("deleted successfully!");
                } else if (choice == 6) {
                    break;
                }
            } catch (ScholarNotFoundException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        sc.close();
    }
}
