package service;

import java.util.List;
import dao.ScholarDao;
import dao.ScholarDaoImpl;
import model.Scholar;
import exception.ScholarNotFoundException;

public class ScholarServiceImpl implements ScholarService {
    private ScholarDao scholarDao;

    public ScholarServiceImpl() {
        this.scholarDao = new ScholarDaoImpl();
    }

    public void addScholar(Scholar scholar) throws Exception {
        scholarDao.addScholar(scholar);
    }

    public Scholar getOneScholar(Integer scholarId) throws Exception {
        return scholarDao.getOneScholar(scholarId);
    }

    public List<Scholar> listAllScholars() throws Exception {
        return scholarDao.listAllScholars();
    }

    public void updateScholarEmail(Integer scholarId, String newEmail) throws Exception {
        scholarDao.updateScholarEmail(scholarId, newEmail);
    }

    public void deleteScholarById(Integer scholarId) throws Exception {
        scholarDao.deleteScholarById(scholarId);
    }
}
