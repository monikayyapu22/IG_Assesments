package model;

public class Scholar {
    private Integer scholarId;
    private String name;
    private String email;
    private String mobile;

    public Scholar(Integer scholarId, String name, String email, String mobile) {
        this.scholarId = scholarId;
        this.name = name;
        this.email = email;
        this.mobile = mobile;
    }
    public Integer getScholarId() {
        return scholarId;
    }
    public void setScholarId(Integer scholarId) {
        this.scholarId = scholarId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @Override
    public String toString() {
        return "Scholar [ScholarId=" + scholarId + ", Name=" + name + ", Email=" + email + ", Mobile=" + mobile + "]";
    }
}
