package com.example.workout.service;

import com.example.workout.model.Workout;
import java.util.List;

public interface WorkoutService {
    Workout addWorkout(Workout workout);
    List<Workout> getAllWorkouts();
    Workout getWorkoutById(Long id);
}
