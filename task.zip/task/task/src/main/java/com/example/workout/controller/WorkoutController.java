package com.example.workout.controller;

import com.example.workout.exception.WorkoutNotFoundException;
import com.example.workout.model.Workout;
import com.example.workout.service.WorkoutService;
//import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class WorkoutController {
 
 @Autowired
 WorkoutService workoutService;
 
 @GetMapping("/workouts")
 public List<Workout> getAllWorkouts(){
  return workoutService.getAllWorkouts();
  
 }
 
 @PostMapping("/add")
	public Workout addWorkout(@RequestBody @Valid Workout workout) {
		return workoutService.addWorkout(workout);
	}
// @PostMapping("/add")
// public ResponseEntity<?> addWorkout(@RequestBody @Valid Workout workout) {
//     if (workout == null || workout.getTitle() == null) {
//         return ResponseEntity.badRequest().body("Invalid request body");
//     }
//     Workout savedWorkout = workoutService.addWorkout(workout);
//     return ResponseEntity.ok(savedWorkout);
// }
 
 @GetMapping("/get/{id}")
 public Workout getWorkoutById(@PathVariable("id") Long id) throws Exception{
  return workoutService.getWorkoutById(id);
 }
 
 @GetMapping("/home")
 public String getMessage() {
  return "home page";
 }
}