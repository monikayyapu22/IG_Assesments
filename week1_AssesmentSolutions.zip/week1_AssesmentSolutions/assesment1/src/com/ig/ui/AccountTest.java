package com.ig.ui;

import com.ig.exception.AccountNotFoundException;
import com.ig.exception.InsufficientFundsException;
import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;
import com.ig.model.Account;
import com.ig.model.Account.AccountType;
import com.ig.service.AccountService;

public class AccountTest {
    public static void main(String[] args) {
        AccountService accountService = new AccountService();

        try {
            Account account1 = new Account(1, "Monika", AccountType.SAVINGS, 2000f);
            Account account2 = new Account(2, "Siri", AccountType.CURRENT, 6000f);
            Account account3 = new Account(3, "Anusha", AccountType.SAVINGS, 4000f);

            accountService.addAccount(account1);
            accountService.addAccount(account2);
            accountService.addAccount(account3);

            
            System.out.println(account1.getCustomerName() + "'s Account balance: " + accountService.getBalance(1));
            accountService.deposit(1, 500f);
            System.out.println(account1.getCustomerName() + "'s Updated Balance after deposit: " + accountService.getBalance(1));

           
            try {
                accountService.deposit(2, -200f);
            } catch (InvalidAmountException e) {
                System.out.println("Error for " + account2.getCustomerName() + ": " + e.getMessage());
            }

           
            try {
                accountService.withdraw(2, 2000f);
                System.out.println(account2.getCustomerName() + "'s Updated Balance after withdrawal: " + accountService.getBalance(2));
            } catch (InvalidAmountException | InsufficientFundsException e) {
                System.out.println("Error for " + account2.getCustomerName() + ": " + e.getMessage());
            }

            
            try {
                accountService.withdraw(1, 200f);
            } catch (InvalidAmountException e) {
                System.out.println("Error for " + account1.getCustomerName() + ": " + e.getMessage());
            }

            
            try {
                accountService.withdraw(1, 2000f);
            } catch (InsufficientFundsException e) {
                System.out.println("Error for " + account1.getCustomerName() + ": " + e.getMessage());
            }

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
