package com.ig.service;

import com.ig.model.Account;
import com.ig.exception.AccountNotFoundException;
import com.ig.exception.InvalidAmountException;
import com.ig.exception.InsufficientFundsException;
import java.util.ArrayList;
import java.util.List;

public class AccountService {
    List<Account> accountList = new ArrayList<>();

    public boolean isValidAccount(int accountNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account number " + accountNumber + " not found");
    }

    public void deposit(int accountNumber, float amount) throws AccountNotFoundException, InvalidAmountException {
        if (amount < 0) {
            throw new InvalidAmountException("Cannot deposit a negative amount");
        }

        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                account.setAccountBalance(account.getAccountBalance() + amount);
                return;
            }
        }
        throw new AccountNotFoundException("Account is not found");
    }

    public void withdraw(int accountNumber, float amount) throws AccountNotFoundException, InvalidAmountException, InsufficientFundsException {
        if (amount < 500) {
            throw new InvalidAmountException("Withdrawal amount must be at least Rs.500");
        }

        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                if (account.getAccountType() == Account.AccountType.SAVINGS && account.getAccountBalance() - amount < 1000) {
                    throw new InsufficientFundsException("Insufficient balance for withdrawal in savings account");
                }
                if (account.getAccountType() == Account.AccountType.CURRENT && account.getAccountBalance() - amount < 5000) {
                    throw new InsufficientFundsException("Insufficient balance for withdrawal in current account");
                }
                account.setAccountBalance(account.getAccountBalance() - amount);
                return;
            }
        }
        throw new AccountNotFoundException("Account is not found");
    }

    public float getBalance(int accountNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account.getAccountBalance();
            }
        }
        throw new AccountNotFoundException("Account not found");
    }

    public void addAccount(Account account) {
        accountList.add(account);
    }
}
