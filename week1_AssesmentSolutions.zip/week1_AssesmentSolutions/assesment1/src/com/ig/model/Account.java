package com.ig.model;

import com.ig.exception.InvalidAmountException;
import com.ig.exception.LowBalanceException;

public class Account {

    public enum AccountType {
        SAVINGS, CURRENT
    }
    
    private Integer accountNumber;
    private String customerName;
    private AccountType accountType; 
    private Float accountBalance;

    public Account(Integer accountNumber, String customerName, AccountType accountType, Float accountBalance) throws LowBalanceException, InvalidAmountException {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.accountType = accountType;

        if (accountBalance < 0) {
            throw new InvalidAmountException("Account balance cannot be negative");
        }
        this.accountBalance = accountBalance;

        
        if (accountType == AccountType.SAVINGS && accountBalance < 1000) {
            throw new LowBalanceException("Insufficient balance in savings account");
        }
        if (accountType == AccountType.CURRENT && accountBalance < 5000) {
            throw new LowBalanceException("Insufficient balance in current account");
        }
    }

    public Integer getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Integer accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public Float getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Float accountBalance) {
        this.accountBalance = accountBalance;
    }
}
